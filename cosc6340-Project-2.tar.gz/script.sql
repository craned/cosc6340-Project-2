select a from (select a,b from (select c from (select d from a) a1 join j) a2) a3;
select ct from c2;
quit;
