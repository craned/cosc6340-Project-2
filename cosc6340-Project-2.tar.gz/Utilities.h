/*******************************************************************************
 File: Engine.cpp
 Author: Amirreza Shirani
 Author: Devin Crane
 Author: sakhitha kanyadhara
 *******************************************************************************/
#ifndef UTILITIES_H
#define UTILITIES_H

#include <string.h>
#include <vector>
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <tuple>
#include <fstream>
#include "fstream"

using namespace std;

class Utilities
{
	public:
		static string cleanSpaces(string sLineIn);
};

#endif

